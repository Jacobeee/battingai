opencv_version = "4.11.0.86"
contrib = False
headless = True
rolling = False
ci_build = True